package io.flutter.plugins.video_player_web;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.PluginRegistry.Registrar;

/** VideoPlayerWebPlugin */
public class VideoPlayerWebPlugin implements FlutterPlugin {
  @Override
  public void onAttachedToEngine(FlutterPluginBinding flutterPluginBinding) {}

  public static void registerWith(Registrar registrar) {}

  @Override
  public void onDetachedFromEngine(FlutterPluginBinding binding) {}
}
